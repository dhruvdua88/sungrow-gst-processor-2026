---
name: gstr1-einvoice-bridge
description: Reconcile a client sales workbook against a GSTN e-invoice portal export and build the "Sales sheet to GSTR-1" bridge with an e-invoice issues register and a missing-IRN root-cause analysis. Use when the user provides a GSTR-1-style sales/books workbook plus an e-invoice portal export ("E-invoice details auto-populated for Form GSTR-1") and asks for a bridge, reconciliation, e-invoice issues, missing IRN, or "why are e-invoices not there".
---

# GSTR-1 E-Invoice Bridge

## Overview

Build one `.xlsx` that maps every books invoice to its GSTR-1 table (B2B Table 4, export Table 6A, zero-value Table 8/9, HSN Table 12), cross-checks filed B2B value against the e-invoice portal, lists every e-invoice issue, and explains why IRNs are missing.

## Workflow

1. **Confirm inputs** - books workbook (one sales sheet of invoice lines) and the GSTN e-invoice portal export workbook. Read `references/input_spec.md` if any input looks different from the standard layout.
2. **Run the bridge script**:
   ```bash
   python3 scripts/gstr1_bridge.py --books <books.xlsx> --portal <portal.xlsx> --output <out.xlsx>
   ```
   Add `--sales-sheet`, `--period MMYYYY`, or `--gstin` only when auto-detection fails. The script prints a summary; check it.
3. **Verify the bridge closes**: the printed "unexplained" value must be `Rs 0.00`. If not, reconcile the difference before reporting (check zero-value-on-portal invoices and matched deviations).
4. **Report** in this order: bridge numbers (books -> portal), top e-invoice issues, then the missing-IRN root cause. Cap the issues list at 5 in chat; the workbook has the full register.
5. **Confirm the snapshot caveat** with the user when "Why missing IRN" shows a stop date: the portal file may be a mid-period snapshot, so recommend re-downloading the current export before concluding e-invoices were never raised.

## Workbook tabs (script output)

- **Bridge**: tax totals, Part 1 mapping (what goes where in GSTR-1), Part 2 books-vs-portal cross-check.
- **E-Invoice Issues**: register with severity, category, invoice, value, issue, action.
- **Missing IRN**: all no-IRN invoices sorted by value, flagged above Rs 5,00,000.
- **Matched invoices (portal)**: books vs portal per invoice, deviations highlighted.
- **Why missing IRN**: snapshot coverage, missing split (above portal max vs mid-period gaps), per-day matched/missing counts, gap detail, root-cause conclusion.
- **Read me**: sources, method, verified-clean checks.

## Rules that must hold

- Classify B2B as: `shipment == Domestic`, GSTIN length 15, invoice value > 0.005. Exports by shipment type. Zero-value otherwise.
- Match books to portal by invoice number (trimmed string); confirm GSTIN agrees on matched invoices.
- Net value deviation line = books value minus portal value on matched invoices.
- Portal total must equal: matched (portal value) + zero-value-in-books-but-on-portal values. Everything else is "unexplained".
- Never fabricate IRNs, GSTINs, or values not present in the source files.
- The books "E-invoice" column often stores the customer GSTIN, not an IRN - do not treat it as IRN presence.

## Resources

- `scripts/gstr1_bridge.py` - deterministic bridge + issues + root-cause builder (run it; edit only if input layout differs).
- `references/input_spec.md` - expected layouts, classification rules, and known pitfalls. Read when inputs deviate from the standard shape.
