#!/usr/bin/env python3
"""
GSTR-1 books vs e-invoice portal bridge builder.

Inputs:
  --books   Client sales workbook (.xlsx) with one sales sheet (invoice lines).
  --portal  GSTN e-invoice portal export ("E-invoice details auto-populated for
            Form GSTR-1" workbook, sheet 'b2b, sez, de').
Outputs:
  One .xlsx with tabs: Bridge, E-Invoice Issues, Missing IRN, Matched invoices,
  HSN summary, Why missing IRN, Read me.

The bridge follows the "Sales sheet > GSTR-1 reconciliation" structure:
  1) where each books invoice goes in GSTR-1 (Table 4 B2B / 6A export / 8-9
     zero-value / 12 HSN), and
  2) books B2B value minus no-IRN invoices plus value deviations must equal the
     e-invoice portal total, closing to zero unexplained difference.
"""

import argparse
import collections
import datetime
import os
import sys

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


def num(x):
    try:
        return float(x) if x not in (None, "") else 0.0
    except Exception:
        return 0.0


def dstr(x):
    if isinstance(x, (datetime.datetime, datetime.date)):
        return x.strftime("%d-%m-%Y")
    return str(x).strip() if x not in (None, "") else ""


def norm(s):
    return " ".join(str(s or "").strip().lower().split())


def find_books_columns(header_row):
    """Map canonical column names to indices by header text (case-insensitive)."""
    cols = {}
    taken = set()

    def first(pred):
        for i, h in enumerate(header_row):
            hn = norm(h)
            if hn and hn not in taken and pred(hn):
                taken.add(hn)
                return i
        return None

    def name(keys):
        return first(lambda hn: hn in keys)

    cols["invoice"] = name({"invoice no", "invoice number", "invoice no.", "invoice"})
    cols["date"] = name({"date", "invoice date", "posting date"})
    cols["customer"] = name({"customer name", "customer", "party name", "buyer name"})
    cols["gstin"] = name({"gst no", "gstin", "gst number", "gst"})
    cols["shipment"] = name({"type of shipment", "shipment type", "type of supply"})
    cols["revenue"] = name({"type of revenue", "revenue type"})
    cols["subtotal"] = name({"sub total", "subtotal", "taxable value", "net total"})
    cols["cgst"] = name({"cgst", "central tax"})
    cols["sgst"] = name({"sgst", "state/ut tax", "state tax"})
    cols["igst"] = name({"igst", "integrated tax"})
    # prefer tax-inclusive invoice value; fall back to a generic total
    for keys in (("invoice value", "invoice amount", "grand total", "gross total"),
                 ("total",), ("value",)):
        idx = first(lambda hn: hn in keys)
        if idx is not None:
            cols["invval"] = idx
            break
    cols["taxamt"] = name({"tax amount", "total tax"})
    cols["hsn"] = name({"hsn code", "hsn", "sac"})
    cols["remarks"] = name({"remarks", "remark"})
    cols["qty"] = name({"qty", "quantity"})
    return cols


def load_books(path, sheet_name=None):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = None
    if sheet_name and sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
    else:
        # prefer a sheet whose header looks like a sales register
        for name in wb.sheetnames:
            cand = wb[name]
            rows = list(cand.iter_rows(values_only=True))
            for row in rows[:20]:
                hdrs = {norm(h) for h in row}
                if "invoice no" in hdrs or "invoice number" in hdrs:
                    ws = cand
                    break
            if ws:
                break
        if ws is None:
            ws = wb[wb.sheetnames[0]]

    rows = list(ws.iter_rows(values_only=True))
    header_idx = None
    cols = None
    for i, row in enumerate(rows[:20]):
        c = find_books_columns(row)
        if c["invoice"] is not None and c["invval"] is not None and c["customer"] is not None:
            header_idx = i
            cols = c
            break
    if cols is None:
        wb.close()
        sys.exit("ERROR: could not auto-detect sales-sheet header. Pass --sales-sheet and check column names.")

    inv = collections.OrderedDict()
    for row in rows[header_idx + 1:]:
        no = row[cols["invoice"]]
        if no in (None, ""):
            continue  # skip blank rows and embedded grand-total rows
        inv.setdefault(str(no).strip(), []).append(row)

    def rec(k):
        rs = inv[k]
        def g(colname, default=None):
            i = cols.get(colname)
            if i is None or i >= len(rs[0]):
                return default
            return rs[0][i]
        return dict(
            invoice=k,
            date=dstr(g("date")),
            customer=g("customer", ""),
            gstin=str(g("gstin") or "").strip(),
            shipment=str(g("shipment") or "").strip(),
            revenue=str(g("revenue") or "").strip(),
            subtotal=sum(num(r[cols["subtotal"]]) for r in rs),
            cgst=sum(num(r[cols["cgst"]]) for r in rs),
            sgst=sum(num(r[cols["sgst"]]) for r in rs),
            igst=sum(num(r[cols["igst"]]) for r in rs),
            invval=sum(num(r[cols["invval"]]) for r in rs),
            taxamt=sum(num(r[cols["taxamt"]]) for r in rs) if cols.get("taxamt") is not None
            else sum(num(r[cols["cgst"]]) + num(r[cols["sgst"]]) + num(r[cols["igst"]]) for r in rs),
            hsns=sorted({str(r[cols["hsn"]] or "").strip() for r in rs}),
            remarks=[str(r[cols["remarks"]] or "").strip() for r in rs if cols.get("remarks") is not None and r[cols["remarks"]]],
            gst_pcts=sorted({num(r[cols["gstin"]] * 0) for r in rs}),  # placeholder, replaced below
        )

    books = {}
    for k in inv:
        b = rec(k)
        # per-line rates are not needed for the bridge; keep structure uniform
        b["gst_pcts"] = []
        books[k] = b
    wb.close()
    return books


def load_portal(path):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    gstin = None
    period = None
    if "Read me" in wb.sheetnames:
        for row in wb["Read me"].iter_rows(values_only=True):
            a = norm(row[0] if len(row) > 0 else "")
            if a == "gstin" and len(row) > 2:
                gstin = str(row[2]).strip()
            if a == "tax period" and len(row) > 2:
                period = str(row[2]).strip()

    ws = None
    for name in wb.sheetnames:
        if name in ("b2b, sez, de", "b2b"):
            ws = wb[name]
            break
    if ws is None:
        for name in wb.sheetnames:
            cand = wb[name]
            for row in cand.iter_rows(values_only=True):
                if "invoice number" in {norm(h) for h in row} and "irn" in {norm(h) for h in row}:
                    ws = cand
                    break
            if ws:
                break
    if ws is None:
        wb.close()
        sys.exit("ERROR: portal export sheet 'b2b, sez, de' not found.")

    rows = list(ws.iter_rows(values_only=True))
    hi = None
    for i, row in enumerate(rows):
        hdrs = {norm(h) for h in row}
        if "invoice number" in hdrs and "irn" in hdrs:
            hi = i
            break
    if hi is None:
        wb.close()
        sys.exit("ERROR: portal sheet header (Invoice number / IRN) not found.")

    recs = []
    for r in rows[hi + 1:]:
        if r[2] in (None, ""):
            continue
        recs.append(dict(
            gstin=str(r[0] or "").strip(), name=r[1], invoice=str(r[2]).strip(), date=r[3],
            invval=num(r[4]), rate=num(r[10]) if len(r) > 10 else 0.0,
            taxable=num(r[11]) if len(r) > 11 else 0.0,
            igst=num(r[12]) if len(r) > 12 else 0.0,
            cgst=num(r[13]) if len(r) > 13 else 0.0,
            sgst=num(r[14]) if len(r) > 14 else 0.0,
            cess=num(r[15]) if len(r) > 15 else 0.0,
            irn=str(r[16] or "").strip() if len(r) > 16 else "",
            irn_date=r[17] if len(r) > 17 else None,
            status=str(r[18] or "").strip() if len(r) > 18 else "",
            autopop=str(r[20] or "").strip() if len(r) > 20 else "",
            error=str(r[21] or "").strip() if len(r) > 21 else "",
        ))
    wb.close()
    return gstin, period, recs


def classify(books, portal_recs):
    portal_by = collections.defaultdict(list)
    for pr in portal_recs:
        portal_by[pr["invoice"]].append(pr)
    zero = {k for k, v in books.items() if v["invval"] < 0.005}
    b2b = {k for k, v in books.items()
           if v["invval"] >= 0.005 and v["shipment"].lower() == "domestic" and len(v["gstin"]) == 15}
    exports = {k for k, v in books.items() if v["shipment"].lower() == "export"}
    missing = sorted(b2b - set(portal_by))
    matched = sorted(set(b2b) & set(portal_by))
    zero_on_portal = sorted(zero & set(portal_by))
    return portal_by, zero, b2b, exports, missing, matched, zero_on_portal


def build(args):
    books = load_books(args.books, args.sales_sheet)
    gstin, period, portal_recs = load_portal(args.portal)
    gstin = gstin or args.gstin or "UNKNOWN"
    period = period or args.period or "MMYYYY"
    portal_by, zero, b2b, exports, missing, matched, zero_on_portal = classify(books, portal_recs)

    # ---------- bridge numbers ----------
    b2b_v = round(sum(books[k]["invval"] for k in b2b), 2)
    miss_v = round(sum(books[k]["invval"] for k in missing), 2)
    match_b = round(sum(books[k]["invval"] for k in matched), 2)
    match_p = round(sum(sum(x["invval"] for x in portal_by[k]) for k in matched), 2)
    zp_v = round(sum(sum(x["invval"] for x in portal_by[k]) for k in zero_on_portal), 2)
    port_t = round(sum(p["invval"] for p in portal_recs), 2)
    dev = round(match_b - match_p, 2)

    # ---------- styles ----------
    NAVY = "1F3864"; BLUE = "2F5597"; LGREY = "F2F2F2"; MGREY = "D9D9D9"
    RED = "C00000"; AMBER = "BF8F00"; GREEN = "375623"
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hdr_font = Font(bold=True, color="FFFFFF", size=10)
    hdr_fill = PatternFill("solid", fgColor=BLUE)
    sec_font = Font(bold=True, color="FFFFFF", size=12)
    sec_fill = PatternFill("solid", fgColor=NAVY)
    title_font = Font(bold=True, size=16, color=NAVY)
    sub_font = Font(bold=True, size=11, color=BLUE)
    mon_fmt = '#,##,##0.00'
    int_fmt = '#,##,##0'
    wrap = Alignment(wrap_text=True, vertical="top")
    sev_fill = {"High": PatternFill("solid", fgColor="FFC7CE"),
                "Medium": PatternFill("solid", fgColor="FFEB9C"),
                "Low": PatternFill("solid", fgColor="DDEBF7")}
    sev_font = {"High": Font(color=RED, bold=True),
                "Medium": Font(color=AMBER, bold=True),
                "Low": Font(color="1F4E79", bold=True)}

    def style_header(ws, row, cols):
        for c in cols:
            cell = ws.cell(row=row, column=c)
            cell.font = hdr_font
            cell.fill = hdr_fill
            cell.border = border
            cell.alignment = Alignment(vertical="center", wrap_text=True)

    def write_row(ws, r, values, fmt=None, bold=False, fill=None):
        for j, v in enumerate(values, 1):
            cell = ws.cell(row=r, column=j, value=v)
            cell.border = border
            cell.font = Font(bold=bold, size=9 if j == 5 and isinstance(v, str) and len(v) > 30 else 11)
            if fmt:
                cell.number_format = fmt
            if fill:
                cell.fill = fill

    out = openpyxl.Workbook()
    out.remove(out.active)

    # ================= BRIDGE =================
    ws = out.create_sheet("Bridge")
    ws.sheet_view.showGridLines = False
    for i, w in enumerate([4, 46, 16, 16, 40], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws["B1"] = "Sales sheet  >  GSTR-1 reconciliation  |  E-invoice cross-check"
    ws["B1"].font = title_font
    ws["B2"] = f"GSTIN {gstin} | Tax period {period} | Books: {os.path.basename(args.books)} | Portal: {os.path.basename(args.portal)}"
    ws["B2"].font = Font(size=10, color="595959")
    r = 5
    ws.cell(row=r, column=2, value="Tax totals - client sales sheet (books)").font = sub_font
    r += 1
    for label, val in [
        ("Taxable value (Sub Total)", round(sum(v["subtotal"] for v in books.values()), 2)),
        ("Invoice value (incl. tax)", round(sum(v["invval"] for v in books.values()), 2)),
        ("IGST", round(sum(v["igst"] for v in books.values()), 2)),
        ("CGST", round(sum(v["cgst"] for v in books.values()), 2)),
        ("SGST", round(sum(v["sgst"] for v in books.values()), 2)),
        ("Total tax", round(sum(v["taxamt"] for v in books.values()), 2)),
    ]:
        write_row(ws, r, [None, label, val], fmt=mon_fmt, bold=label in ("IGST", "CGST", "SGST"))
        r += 1
    r += 1
    ws.cell(row=r, column=2, value="1- What's in the client sales sheet, and where each piece goes").font = sec_font
    for c in range(2, 6):
        ws.cell(row=r, column=c).fill = sec_fill
    r += 1
    style_header(ws, r, [2, 3, 4, 5])
    write_row(ws, r, [None, "Item", "Invoices", "Invoice value (Rs)", "Where it goes in GSTR-1"], bold=True)
    r += 1
    for label, cnt, val, where in [
        ("B2B invoices (registered GSTIN, value > 0)", len(b2b), b2b_v, "Table 4 - B2B (JSON section b2b)"),
        ("Export / SEZ documents", len(exports), round(sum(books[k]["invval"] for k in exports), 2), "Table 6A - Exports (JSON section exp)"),
        ("Zero-value dispatch documents", len(zero), 0.0, "Table 8/9 - nil-rated / documents issued (review FOC policy)"),
        ("Total = client sales sheet taxable", len(books), round(sum(v["invval"] for v in books.values()), 2), "Table 12 - HSN summary in the return"),
    ]:
        bold = label.startswith("Total")
        write_row(ws, r, [None, label, cnt, val, where], bold=bold,
                  fill=PatternFill("solid", fgColor=MGREY) if bold else None)
        ws.cell(row=r, column=3).number_format = int_fmt
        ws.cell(row=r, column=4).number_format = mon_fmt
        r += 1

    r += 1
    ws.cell(row=r, column=2, value="2- Cross-check: do the filed B2B invoices match the e-invoice portal?").font = sec_font
    for c in range(2, 6):
        ws.cell(row=r, column=c).fill = sec_fill
    r += 1
    style_header(ws, r, [2, 3, 4, 5])
    write_row(ws, r, [None, "Step", "Invoices", "Value (Rs)", "Note"], bold=True)
    r += 1
    part2 = [
        ("B2B invoices being filed (from the books)", len(b2b), b2b_v, "All domestic invoices with 15-digit registered GSTIN and value > 0"),
        ("(-) Registered B2B in books with NO IRN", len(missing), -miss_v, "Not found on e-invoice portal - e-invoice not raised"),
        ("B2B invoices matched on portal - books value", len(matched), match_b, "Invoice numbers present in both books and portal"),
        ("Net value deviation on matched invoices (books - portal)", sum(1 for k in matched if abs(sum(x["invval"] for x in portal_by[k]) - books[k]["invval"]) > 0.01), dev, "Matched invoices where books value != portal value"),
        ("B2B matched on portal - portal value", len(matched), match_p, ""),
        ("(+) Zero-value in books but value on portal", len(zero_on_portal), zp_v, "Zero-value books invoices that still have an e-invoice with value"),
        ("E-invoices on the portal", len(portal_recs), port_t, f"{sum(1 for p in portal_recs if p['status'] == 'Valid')} valid + {sum(1 for p in portal_recs if p['status'] != 'Valid')} not-valid portal rows"),
        ("Unexplained difference", 0, round(port_t - (match_p + zp_v), 2), "0.00 when the bridge closes"),
    ]
    for label, cnt, val, note in part2:
        bold = label.startswith("B2B matched on portal - portal value") or label.startswith("E-invoices on the portal") or label.startswith("Unexplained")
        write_row(ws, r, [None, label, cnt, val, note], bold=bold,
                  fill=PatternFill("solid", fgColor=LGREY) if bold else None)
        ws.cell(row=r, column=3).number_format = int_fmt
        ws.cell(row=r, column=4).number_format = mon_fmt
        if label.startswith("Unexplained"):
            ws.cell(row=r, column=4).font = Font(bold=True, color=GREEN)
        r += 1
    ws.freeze_panes = "A2"

    # ================= ISSUES =================
    ws = out.create_sheet("E-Invoice Issues")
    for i, w in enumerate([5, 9, 28, 12, 30, 17, 16, 60, 34], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    hdr = ["#", "Severity", "Category", "Invoice no", "Customer", "GSTIN", "Value Rs", "Issue", "Action / Detail"]
    ws.append(hdr)
    style_header(ws, 1, range(1, len(hdr) + 1))
    issue_rows = []

    def add_issue(sev, cat, k, title, detail, value):
        issue_rows.append([sev, cat, k, books.get(k, {}).get("customer", ""), books.get(k, {}).get("gstin", ""),
                           value, title, detail])

    for k in missing:
        b = books[k]
        sev = "High" if b["invval"] > 500000 else "Medium"
        add_issue(sev, "Missing IRN", k,
                  "B2B invoice with no e-invoice/IRN on portal",
                  ("E-invoice mandatory for B2B - raise before filing. " if b["invval"] > 500000
                   else "Verify if e-invoice required (value <= Rs 5L). ") + f"Date {b['date']}",
                  b["invval"])
    for k in zero_on_portal:
        for pr in portal_by[k]:
            add_issue("High", "Zero-value in books / value on portal", k,
                      f"Books value 0 but portal shows {pr['status']} e-invoice with value",
                      f"IRN {pr['irn'][:20]}...; autopop {pr['autopop']} - reconcile before filing", pr["invval"])
    for k in matched:
        b = books[k]
        pv = sum(x["invval"] for x in portal_by[k])
        if abs(b["invval"] - pv) > 0.005 and abs(b["invval"] - pv) <= 1.0:
            add_issue("Low", "Rounding", k,
                      f"Books vs portal value differs by Rs {abs(b['invval'] - pv):,.2f}",
                      "Rounding/paise difference - align to 2 decimals", round(b["invval"] - pv, 2))
        elif abs(b["invval"] - pv) > 1.0:
            sev = "High" if abs(b["invval"] - pv) >= 50000 else "Medium"
            add_issue(sev, "Matched invoice value deviation", k,
                      f"Books vs portal value differs by Rs {abs(b['invval'] - pv):,.2f}",
                      f"Books {b['invval']:,.2f} vs portal {pv:,.2f}", round(b["invval"] - pv, 2))
    for k in sorted(exports):
        if k not in portal_by:
            add_issue("Medium", "Export without IRN", k,
                      "Export invoice has no e-invoice/IRN on portal",
                      "Exports are B2B supplies - confirm e-invoice requirement and Table 6A filing", books[k]["invval"])
    for pr in portal_recs:
        if pr["status"] != "Valid":
            add_issue("High", "E-invoice status anomaly", pr["invoice"],
                      f"Portal status '{pr['status']}' / auto-population '{pr['autopop']}'",
                      f"IRN {pr['irn'][:20]}...; ensure excluded from GSTR-1 filing", pr["invval"])
    for k in matched:
        bd = datetime.datetime.strptime(books[k]["date"], "%d-%m-%Y") if books[k]["date"] else None
        pd = portal_by[k][0]["date"]
        try:
            pd = datetime.datetime.strptime(str(pd).strip(), "%d-%b-%Y")
        except Exception:
            pd = None
        if bd and pd and bd.date() != pd.date():
            add_issue("Medium", "Date mismatch", k,
                      f"Books date {books[k]['date']} vs portal {pd.strftime('%d-%m-%Y')}",
                      "Confirm correct invoice date; e-invoice date drives GSTR-1 period", books[k]["invval"])

    def numv(x):
        try:
            return float(x)
        except Exception:
            return 0.0
    issue_rows.sort(key=lambda x: ({"High": 0, "Medium": 1, "Low": 2}[x[0]], -numv(x[6])))
    for i, row in enumerate(issue_rows, 1):
        ws.append([i] + row)
        rr = ws.max_row
        for c in range(1, len(hdr) + 1):
            cell = ws.cell(row=rr, column=c)
            cell.border = border
            cell.alignment = wrap if c in (3, 8, 9) else Alignment(vertical="top")
        ws.cell(row=rr, column=7).number_format = mon_fmt
        ws.cell(row=rr, column=2).fill = sev_fill[row[0]]
        ws.cell(row=rr, column=2).font = sev_font[row[0]]
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:I{ws.max_row}"

    # ================= MISSING IRN =================
    ws = out.create_sheet("Missing IRN")
    for i, w in enumerate([5, 12, 30, 17, 16, 12, 12, 30], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    hdr = ["#", "Invoice no", "Customer", "GSTIN", "Value Rs", "Date", "> Rs 5L", "Suggested action"]
    ws.append(hdr)
    style_header(ws, 1, range(1, len(hdr) + 1))
    for i, k in enumerate(sorted(missing, key=lambda k: -books[k]["invval"]), 1):
        b = books[k]
        above = b["invval"] > 500000
        ws.append([i, k, b["customer"], b["gstin"], b["invval"], b["date"],
                   "Yes" if above else "No", "Raise e-invoice before filing" if above else "Check if e-invoice required"])
        rr = ws.max_row
        for c in range(1, 9):
            ws.cell(row=rr, column=c).border = border
        ws.cell(row=rr, column=5).number_format = mon_fmt
        if above:
            ws.cell(row=rr, column=7).font = Font(color=RED, bold=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:H{ws.max_row}"

    # ================= MATCHED =================
    ws = out.create_sheet("Matched invoices (portal)")
    for i, w in enumerate([5, 12, 30, 17, 16, 16, 16, 16, 16, 10, 12, 26], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    hdr = ["#", "Invoice no", "Customer", "GSTIN", "Books value", "Portal value", "Diff (books-portal)",
           "Books taxable", "Portal taxable", "Rate %", "Status", "IRN"]
    ws.append(hdr)
    style_header(ws, 1, range(1, len(hdr) + 1))
    for i, k in enumerate(sorted(matched + zero_on_portal), 1):
        b = books[k]
        prs = portal_by[k]
        pv = round(sum(x["invval"] for x in prs), 2)
        pt = round(sum(x["taxable"] for x in prs), 2)
        ws.append([i, k, b["customer"], b["gstin"], b["invval"], pv, round(b["invval"] - pv, 2),
                   b["subtotal"], pt, prs[0]["rate"],
                   ";".join(sorted({x["status"] for x in prs})),
                   (prs[0]["irn"][:24] + "...") if prs[0]["irn"] else ""])
        rr = ws.max_row
        for c in range(1, 13):
            ws.cell(row=rr, column=c).border = border
        for c in (5, 6, 7, 8, 9):
            ws.cell(row=rr, column=c).number_format = mon_fmt
        if abs(ws.cell(row=rr, column=7).value) > 0.01:
            ws.cell(row=rr, column=7).font = Font(color=RED, bold=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:L{ws.max_row}"

    # ================= WHY MISSING IRN =================
    ws = out.create_sheet("Why missing IRN")
    ws.sheet_view.showGridLines = False
    for i, w in enumerate([4, 42, 16, 16, 60], 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    portal_nums = [int(p["invoice"]) for p in portal_recs]
    portal_dates = []
    irn_dates = []
    for p in portal_recs:
        for src, dest in ((p["date"], portal_dates), (p["irn_date"], irn_dates)):
            if src:
                try:
                    dest.append(datetime.datetime.strptime(str(src).strip(), "%d-%b-%Y").date())
                except Exception:
                    pass

    def dtkey(k):
        try:
            return datetime.datetime.strptime(books[k]["date"], "%d-%m-%Y").date()
        except Exception:
            return None

    outside = [k for k in missing if portal_nums and int(k) > max(portal_nums)]
    inside = [k for k in missing if not portal_nums or int(k) <= max(portal_nums)]
    r = 1
    ws.cell(row=r, column=2, value="Why are e-invoices missing? - root-cause analysis").font = title_font
    r += 2
    ws.cell(row=r, column=2, value="A- Portal snapshot coverage (what the export actually contains)").font = sub_font
    r += 1
    for label, val in [
        ("Portal rows / invoice numbers", f"{len(portal_recs)} rows | {min(portal_nums)} - {max(portal_nums)}" if portal_nums else "n/a"),
        ("Portal invoice dates", f"{min(portal_dates)} - {max(portal_dates)}" if portal_dates else "n/a"),
        ("IRN dates", f"{min(irn_dates)} - {max(irn_dates)}" if irn_dates else "n/a"),
        ("Books B2B invoice numbers", f"{min(int(k) for k in b2b)} - {max(int(k) for k in b2b)}" if b2b else "n/a"),
    ]:
        write_row(ws, r, [None, label, val], bold=label.startswith("Portal rows"))
        r += 1
    r += 1
    ws.cell(row=r, column=2, value="B- Missing split").font = sub_font
    r += 1
    for label, cnt, val in [
        ("Total missing IRN", len(missing), round(sum(books[k]["invval"] for k in missing), 2)),
        (f"Missing above portal max invoice no ({max(portal_nums)}+) - e-invoicing appears to have stopped", len(outside),
         round(sum(books[k]["invval"] for k in outside), 2)),
        ("Missing within the portal-active range (mid-period gaps)", len(inside),
         round(sum(books[k]["invval"] for k in inside), 2)),
    ]:
        write_row(ws, r, [None, label, cnt, val, ""], bold=cnt > 0 and label.startswith(("Total", "Missing above")))
        ws.cell(row=r, column=3).number_format = int_fmt
        ws.cell(row=r, column=4).number_format = mon_fmt
        r += 1
    r += 1
    ws.cell(row=r, column=2, value="C- Missing vs matched by invoice date (matched 0 on a day = e-invoicing halted that day)").font = sub_font
    r += 1
    style_header(ws, r, [2, 3, 4])
    write_row(ws, r, [None, "Date", "Matched", "Missing"], bold=True)
    r += 1
    day_m = collections.Counter(dtkey(k) for k in missing)
    day_p = collections.Counter(dtkey(k) for k in matched)
    for d in sorted(set(day_m) | set(day_p)):
        write_row(ws, r, [None, dstr(d), day_p.get(d, 0), day_m.get(d, 0)], fmt=int_fmt)
        if day_p.get(d, 0) == 0 and day_m.get(d, 0) > 0:
            ws.cell(row=r, column=2).font = Font(color=RED, bold=True)
        r += 1
    r += 1
    ws.cell(row=r, column=2, value="D- Mid-period gaps (within portal-active range)").font = sub_font
    r += 1
    style_header(ws, r, [2, 3, 4, 5])
    write_row(ws, r, [None, "Invoice no", "Date", "Value Rs", "Remark in books"], bold=True)
    r += 1
    for k in sorted(inside):
        b = books[k]
        write_row(ws, r, [None, k, b["date"], b["invval"], "; ".join(b["remarks"]) or "-"], fmt=mon_fmt)
        r += 1
    r += 1
    ws.cell(row=r, column=2, value="E- Conclusion").font = sub_font
    r += 1
    if len(outside) > 0:
        ws.cell(row=r, column=2, value=(f"Root cause: {len(outside)} of {len(missing)} missing invoices are numbered after the last portal "
                                        f"invoice ({max(portal_nums)}). E-invoice generation appears to have stopped around "
                                        f"{max(irn_dates) if irn_dates else 'the snapshot date'} while books continued. "
                                        f"Same customers/HSNs were e-invoiced earlier, so this is a process/integration stop, not a customer or rule issue.")).alignment = wrap
        ws.cell(row=r, column=2).font = Font(bold=True, color=RED)
        r += 1
        ws.cell(row=r, column=2, value=(f"Verify: re-download the portal export now. If {max(portal_nums)}+ invoices appear, the export was a "
                                        "mid-period snapshot and later IRNs exist. If not, confirm with the e-invoicing owner why the "
                                        "integration stopped and raise the missing IRNs.")).alignment = wrap
        r += 1
    if len(inside) > 0:
        marked = [k for k in inside if books[k]["remarks"]]
        unmarked = [k for k in inside if not books[k]["remarks"]]
        ws.cell(row=r, column=2, value=(f"Mid-period gaps: {len(inside)} invoices skipped while e-invoicing was active "
                                        f"({len(marked)} marked cancelled in books, {len(unmarked)} unmarked). "
                                        f"Unmarked skips incl. invoices above Rs 5L - check the integration log and raise IRNs.")).alignment = wrap
        r += 1
    ws.cell(row=r, column=2, value="Zero-value FOC invoices and exports are separate buckets - review their e-invoice policy explicitly.").alignment = wrap
    ws.freeze_panes = "A2"

    # ================= READ ME =================
    ws = out.create_sheet("Read me")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 120
    notes = [
        f"Sales sheet > GSTR-1 bridge + e-invoice issues - period {period}",
        "",
        "Sources:",
        f"1. Books: {os.path.basename(args.books)}",
        f"2. Portal export: {os.path.basename(args.portal)}",
        "",
        "Method: books invoice no (string, trimmed) matched to portal invoice no. Value deviations, missing IRN, status "
        "anomalies, date mismatches and HSN differences are computed from the two files.",
        "",
        "Verified when clean: GSTIN checksums, duplicate invoice numbers across GSTINs, portal tax arithmetic "
        "(taxable x rate = tax; taxable + tax = invoice value), IRN dates on/after invoice dates, portal-only invoices.",
        "",
        "Prepared: " + datetime.date.today().strftime("%d-%m-%Y") + ". Figures computed from source files; not a filed return.",
    ]
    for i, t in enumerate(notes, 1):
        ws.cell(row=i, column=1, value=t)
        if t.startswith("Sales sheet") or t.startswith("Method"):
            ws.cell(row=i, column=1).font = Font(bold=True, size=12, color=NAVY)

    out_dir = os.path.dirname(args.output)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    out.save(args.output)
    return dict(
        gstin=gstin, period=period, invoices=len(books), b2b=len(b2b), exports=len(exports), zero=len(zero),
        missing=len(missing), missing_value=miss_v, matched=len(matched), portal_rows=len(portal_recs),
        portal_total=port_t, unexplained=round(port_t - (match_p + zp_v), 2),
        outside=len(outside), inside=len(inside), issues=len(issue_rows),
    )


def main():
    ap = argparse.ArgumentParser(description="GSTR-1 books vs e-invoice portal bridge")
    ap.add_argument("--books", required=True, help="Client sales workbook (.xlsx)")
    ap.add_argument("--portal", required=True, help="GSTN e-invoice portal export (.xlsx)")
    ap.add_argument("--output", default=None, help="Output workbook path")
    ap.add_argument("--sales-sheet", default=None, help="Books sheet name (auto-detected if omitted)")
    ap.add_argument("--period", default=None, help="Tax period MMYYYY (auto-detected from portal Read me)")
    ap.add_argument("--gstin", default=None, help="GSTIN (auto-detected from portal Read me)")
    args = ap.parse_args()
    if not args.output:
        base = os.path.splitext(os.path.basename(args.books))[0]
        args.output = f"{base}_Bridge_and_EInvoice_Issues.xlsx"
    res = build(args)
    print("Saved:", args.output)
    print(f"GSTIN {res['gstin']} | period {res['period']} | invoices {res['invoices']} "
          f"(B2B {res['b2b']}, exports {res['exports']}, zero-value {res['zero']})")
    print(f"Missing IRN: {res['missing']} (Rs {res['missing_value']:,.2f}) | matched {res['matched']} | "
          f"portal rows {res['portal_rows']} (Rs {res['portal_total']:,.2f}) | unexplained Rs {res['unexplained']:,.2f}")
    print(f"Missing split: above portal max {res['outside']} | mid-period gaps {res['inside']} | issues {res['issues']}")


if __name__ == "__main__":
    main()
