# Input spec and pitfalls

## Books workbook (client sales sheet)

One sheet of invoice lines (multiple rows per invoice allowed). The script auto-detects columns by header text:

| Needed field | Header examples recognised |
|---|---|
| Invoice no | "Invoice no", "Invoice number" |
| Date | "Date", "Invoice date", "Posting date" (first match wins) |
| Customer | "Customer name", "Customer", "Party name" |
| GSTIN | "GST NO", "GSTIN", "GST number" |
| Shipment type | "Type of Shipment", "Shipment type" (values like Domestic / Export) |
| Revenue type | "Type of Revenue" |
| Taxable value | "Sub Total", "Subtotal", "Taxable value", "Net total" |
| CGST / SGST / IGST | exact names, or "Central tax" / "State/UT tax" / "Integrated tax" |
| Invoice value (tax-inclusive) | "Invoice Value", "Invoice amount", "Grand total", fallback "Total" |
| Tax amount | "Tax amount", "Total tax" (falls back to CGST+SGST+IGST) |
| HSN | "HSN Code", "HSN", "SAC" |
| Remarks | "Remarks" |

Pitfalls:
- Header names can repeat (e.g., two "Date" columns: invoice date and BOE date) - the first match is used.
- Prefer the tax-inclusive invoice value over a pre-tax "Total" column; picking the wrong one inflates deviation counts.
- Blank rows and embedded grand-total rows (invoice no empty) are skipped automatically.
- The "E-invoice" column commonly holds the customer GSTIN (same as GST NO), not an IRN. IRN presence can only be proven from the portal export.

## Portal export (GSTN "E-invoice details auto-populated for Form GSTR-1")

- Sheet `Read me`: rows `GSTIN` and `Tax Period` (column C) are auto-read for GSTIN and period.
- Sheet `b2b, sez, de` (or `b2b`): header row contains "Invoice number" and "IRN". Column positions used (0-based): GSTIN 0, receiver 1, invoice no 2, date 3, invoice value 4, rate 10, taxable 11, IGST 12, CGST 13, SGST 14, cess 15, IRN 16, IRN date 17, status 18, auto-population status 20, error 21.
- `hsn(b2b)` sheet: HSN at col 0, taxable at col 4, IGST 6, CGST 7, SGST 8, cess 9 (used only if an HSN tab is requested).

## Classification rules

- Zero-value invoice: invoice value < 0.005.
- B2B (filed) invoice: value >= 0.005, shipment Domestic, 15-char GSTIN.
- Export: shipment Export.
- Missing IRN: B2B invoice number absent from portal invoice numbers.
- "Why missing IRN" buckets: missing with invoice no <= portal max = mid-period gaps; above portal max = e-invoicing appears to have stopped at the snapshot boundary.

## Pitfalls in interpretation

- Books may store per-component rates (GST% 9 = CGST 9 + SGST 9 = 18% total; GST% 2.5 = 5% total). Compare effective rates only: tax/taxable x 100.
- An invoice marked "Cancel Invoice"/"Invoice Cancelled" in books may still exist on the portal with value (valid or cancelled). Check the portal status before calling it consistent.
- Zero-value FOC/replacement invoices usually have no e-invoice; the e-invoice mandate for them is a policy question, not a schema error.
- The portal export may be a mid-period snapshot: if every missing invoice is numbered after the last portal invoice, re-download the current export before concluding e-invoices were never raised.
- All figures are computed from the two source files and are not a filed return.
